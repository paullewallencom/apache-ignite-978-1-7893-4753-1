#Chapter 5
Contains code for Service grid, microservices and streaming
## Projects
 =============================
 * Building code to build a service  
 * Deploying a microservice 
 * Event Streaming and complex event processing