package com.microservices.services.registration.model;

public enum RegistrationType {
   Speaker, Sponsor, General, Corporate
}
