package com.service.grid;

import java.util.Date;

public interface MyDateService {

	public Date getTime();
}
