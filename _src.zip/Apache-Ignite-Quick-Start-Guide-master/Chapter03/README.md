# Chapter 3
## Projects
 =============================
 * Hello-world -> Datagrid basics
 * DataGrid -> Hibernate L2 caching 
 * Session-clustering -> Web Session-clustering
